/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package mainpkg;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.text.Text;

/**
 * FXML Controller class
 *
 * @author HRShanto Productions
 */
public class ITManagerController implements Initializable {

    @FXML
    private Text titleOfTheProjectT;
    @FXML
    private Text clickToSeeT;
    @FXML
    private Text itManagerPanelT;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void operationOfItSystemsB(ActionEvent event) {
    }

    @FXML
    private void businessContinuityB(ActionEvent event) {
    }

    @FXML
    private void cyberSecurityB(ActionEvent event) {
    }

    @FXML
    private void dataManagementB(ActionEvent event) {
    }

    @FXML
    private void technicalSupportB(ActionEvent event) {
    }

    @FXML
    private void dataSourceB(ActionEvent event) {
    }

    @FXML
    private void disasterRecoveryB(ActionEvent event) {
    }

    @FXML
    private void innovationB(ActionEvent event) {
    }
    
}
