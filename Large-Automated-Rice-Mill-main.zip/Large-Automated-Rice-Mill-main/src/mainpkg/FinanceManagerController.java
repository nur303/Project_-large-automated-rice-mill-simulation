/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package mainpkg;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

/**
 * FXML Controller class
 *
 * @author SUSMOY
 */
public class FinanceManagerController implements Initializable {

    @FXML
    private Button CheckingTexButton;
    @FXML
    private Button ProfitAndLoseGraphButton;
    @FXML
    private Button FinuncialStatementsButton;
    @FXML
    private Button RefundProductButton;
    @FXML
    private Button PaymentButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void CheckingTexButtonOnClicked(ActionEvent event) {
    }

    @FXML
    private void ProfitAndLoseGraphButtonOnClicked(ActionEvent event) {
    }

    @FXML
    private void FinuncialStatementsButtonOnClicked(ActionEvent event) {
    }

    @FXML
    private void RefundProductButtonOnClicked(ActionEvent event) {
    }

    @FXML
    private void PaymentButtonOnClicked(ActionEvent event) {
    }
    
}
