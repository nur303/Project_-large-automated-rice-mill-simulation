/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package mainpkg;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

/**
 * FXML Controller class
 *
 * @author SUSMOY
 */
public class HumanResourcesController implements Initializable {

    @FXML
    private Button AddendenceAndLeaveButton;
    @FXML
    private Button TrainingMaterialButton;
    @FXML
    private Button CommunicationButton;
    @FXML
    private Button EditEmployeeButton;
    @FXML
    private Button CompleteInformationButton;
    @FXML
    private Button FeedbackButton;
    @FXML
    private Button BackButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void AddendenceAndLeaveButtonOnClicked(ActionEvent event) {
    }

    @FXML
    private void TrainingMaterialButtonOnClicked(ActionEvent event) {
    }

    @FXML
    private void CommunicationButtonOnClicked(ActionEvent event) {
    }

    @FXML
    private void EditEmployeeOnClicked(ActionEvent event) {
    }

    @FXML
    private void CompleteInformationButtonOnClicked(ActionEvent event) {
    }

    @FXML
    private void FeedbackButtonOnClicked(ActionEvent event) {
    }

    @FXML
    private void BackButtonOnClicked(ActionEvent event) {
    }
    
}
